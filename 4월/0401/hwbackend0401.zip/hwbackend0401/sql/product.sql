create table product(
    product int(11)  primary key AUTO_INCREMENT, 
    name    varchar(45),
    price    int(11),
    info    varchar(1000)
)